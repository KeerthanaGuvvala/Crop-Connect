const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 3000;

// Create a connection to the database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'bhagi',
  database: 'cropconnect'
});

// Connect to the database
db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database: ' + err.stack);
    return;
  }
  console.log('Connected to the database with connection id: ' + db.threadId);
});

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Secret key for JWT signing (should be stored securely in production)
const JWT_SECRET = 'your_secret_key';

// Root route to check server status
app.get('/', (req, res) => {
  res.send('Server is up and running!');
});

// Test route to check database connection
app.get('/test-db', (req, res) => {
  db.query('SELECT 1 + 1 AS solution', (err, results) => {
    if (err) {
      res.status(500).json({ message: 'Error querying the database', error: err });
    } else {
      res.status(200).json({ message: 'Database connection is successful', results: results });
    }
  });
});

// Endpoint for user login with authentication (checks username/email and password)
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Find the user by email
  db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Error querying the database', error: err });
    }

    if (results.length === 0) {
      // User not found, so we should register them automatically
      const name = "New User"; // Use a default name or prompt the user to provide one on the frontend

      bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
          return res.status(500).json({ message: 'Error hashing password', error: err });
        }

        // Add the new user to the database
        db.query('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, hashedPassword], (err, results) => {
          if (err) {
            return res.status(500).json({ message: 'Error adding user', error: err });
          }

          // Generate a JWT token
          const token = jwt.sign(
            { id: results.insertId, name: name, email: email },
            JWT_SECRET,
            { expiresIn: '1h' }
          );

          res.status(200).json({
            message: 'User registered and logged in successfully',
            token: token,
            user: {
              id: results.insertId,
              name: name,
              email: email
            }
          });
        });
      });
    } else {
      // User found, check the password
      const user = results[0];

      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          return res.status(500).json({ message: 'Error comparing passwords', error: err });
        }

        if (!isMatch) {
          // Passwords do not match
          return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Passwords match, generate JWT token
        const token = jwt.sign(
          { id: user.id, name: user.name, email: user.email },
          JWT_SECRET,
          { expiresIn: '1h' }
        );

        res.status(200).json({
          message: 'Login successful',
          token: token,
          user: {
            id: user.id,
            name: user.name,
            email: user.email
          }
        });
      });
    }
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
